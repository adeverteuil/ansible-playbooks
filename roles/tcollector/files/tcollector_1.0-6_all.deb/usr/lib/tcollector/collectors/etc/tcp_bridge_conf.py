#!/usr/bin/env python

def enabled():
  return True

def flush_delay():
  return 60

def port():
  return 4243

def host():
  return '127.0.0.1'
