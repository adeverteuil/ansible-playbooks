#!/usr/bin/env python

def enabled():
  return True

def flush_delay():
  return 60

def usetcp():
  return False
