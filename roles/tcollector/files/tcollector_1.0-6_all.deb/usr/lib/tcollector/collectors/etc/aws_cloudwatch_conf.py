#!/usr/bin/env python
def enabled():
  return True

def get_accesskey_secretkey():
  return ('<access_key_id>', '<secret_access_key>')
