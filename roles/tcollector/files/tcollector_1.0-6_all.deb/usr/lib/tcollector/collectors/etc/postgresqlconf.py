#!/usr/bin/env python

def get_user_password():
  """Returns a tuple (user, password)."""
  # ensure that user has enough power to get data from DB
  return ("root", "")
